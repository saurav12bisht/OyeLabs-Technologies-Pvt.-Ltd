package com.oyelabs.marvel.universe;

public class Stories {
    public Items[] items;

    public Items[] getItems() {
        return items;
    }

    public void setItems(Items[] items) {
        this.items = items;
    }
}
