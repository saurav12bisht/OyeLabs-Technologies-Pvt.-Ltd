package com.oyelabs.marvel.universe;




 public class Model{
int code;

     public int getCode() {
         return code;
     }

     public void setCode(int code) {
         this.code = code;
     }

  public Data data;

     public Data getData() {
         return data;
     }

     public void setData(Data data) {
         this.data = data;
     }
 }