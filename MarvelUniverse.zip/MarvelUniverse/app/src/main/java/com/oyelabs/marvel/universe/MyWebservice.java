package com.oyelabs.marvel.universe;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface MyWebservice {
    String BASE_URL="https://gateway.marvel.com/v1/public/";
    String FEED="characters?ts=1&apikey=1529157892fc386bd7b4411e4b7deaf1&hash=fb5c66a4d3c89f8bda8606383b645dc1";
    String URL="characters/{id}?ts=1&apikey=1529157892fc386bd7b4411e4b7deaf1&hash=fb5c66a4d3c89f8bda8606383b645dc1";
    Retrofit retrofit= new Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    @GET(FEED)
    Call<Model> getposts();

    @GET(URL)
    Call<Model> getsinglepost(@Path("id")int character_id);
}
