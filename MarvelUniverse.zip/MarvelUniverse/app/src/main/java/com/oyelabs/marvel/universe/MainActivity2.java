package com.oyelabs.marvel.universe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;


import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity2 extends AppCompatActivity {

    private MyWebservice myWebservice;
    private ArrayList<Result> resultArrayList;
    private ImageView imageview ;

    private TextView name,desc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name=findViewById(R.id.name);
        desc=findViewById(R.id.desc);


        imageview = findViewById(R.id.imageView);
        String id= getIntent().getStringExtra("id");
        myWebservice= MyWebservice.retrofit.create(MyWebservice.class);
        Toast.makeText(MainActivity2.this, ""+id, Toast.LENGTH_SHORT).show();

        Call<Model> call= myWebservice.getsinglepost(Integer.parseInt(id));
        call.enqueue(new Callback<Model>() {
            @Override
            public void onResponse(Call<Model> call, Response<Model> response) {

                Model model =response.body();
                resultArrayList = new ArrayList(Arrays.asList(model.getData().getResults()));




//


                name.setText(resultArrayList.get(0).getName());
                if(resultArrayList.get(0).getDescription().equals("")){
                    desc.setText("No description present ");
                }else{
                    desc.setText(resultArrayList.get(0).getDescription());
                }

                final String hash="?ts=1&apikey=1529157892fc386bd7b4411e4b7deaf1&hash=fb5c66a4d3c89f8bda8606383b645dc1";
                String url= resultArrayList.get(0).getThumbnail().path+"/"+"portrait_xlarge"+".jpg"+hash;


                Glide.with(MainActivity2.this)
                        .load(url) // image url
                        .placeholder(R.drawable.def_prof) // any placeholder to load at start
                        .error(R.drawable.def_prof)  // any image in case of error
                        .override(200, 200) // resizing
                        .centerCrop()
                        .into(imageview);








            }

            @Override
            public void onFailure(Call<Model> call, Throwable t) {
                Toast.makeText(MainActivity2.this, ""+t, Toast.LENGTH_SHORT).show();
            }
        });



    }
}