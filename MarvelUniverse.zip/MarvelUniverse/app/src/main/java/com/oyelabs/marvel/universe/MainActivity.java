package com.oyelabs.marvel.universe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Result> resultArrayList;
    private  MyWebservice myWebservice;
    private RecyclerView recyclerView;
    private  CustomAdapter adapter;












    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myWebservice= MyWebservice.retrofit.create(MyWebservice.class);
        recyclerView=findViewById(R.id.recyclerview);

        Call<Model> call= myWebservice.getposts();
        call.enqueue(new Callback<Model>() {
            @Override
            public void onResponse(Call<Model> call, Response<Model> response) {

                if(response.body().getCode()==200){
                    Toast.makeText(MainActivity.this, "Application is ready to use", Toast.LENGTH_SHORT).show();
                }
                Model model =response.body();
                resultArrayList = new ArrayList(Arrays.asList(model.getData().getResults()));




                    adapter = new CustomAdapter(MainActivity.this,resultArrayList);
                    recyclerView.setAdapter(adapter);

                GridLayoutManager gridLayoutManager=new GridLayoutManager(MainActivity.this,2);
                recyclerView.setLayoutManager(gridLayoutManager);

            }

            @Override
            public void onFailure(Call<Model> call, Throwable t) {
                Toast.makeText(MainActivity.this, "error- "+t, Toast.LENGTH_SHORT).show();
            }
        });

    }
}