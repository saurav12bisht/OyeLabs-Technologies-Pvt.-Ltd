package com.oyelabs.marvel.universe;

import android.content.Context;
import android.content.Intent;
import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder>   {

    Context context;

    ArrayList<Result> list;
    Glide glide;


    public CustomAdapter(Context context, ArrayList<Result> list) {
        this.context = context;
        this.list = list;

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_list, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.name.setText(list.get(position).getName());
        String description = list.get(position).getDescription();
        if (description.equals("")) {
            holder.description.setText("No description present ");
        } else {

            holder.description.setText(list.get(position).getDescription());
        }


        String url = list.get(position).getThumbnail().path;
        String hash = "?ts=1&apikey=1529157892fc386bd7b4411e4b7deaf1&hash=fb5c66a4d3c89f8bda8606383b645dc1";
        glide.with(holder.description.getContext()).load(url + "/portrait_xlarge.jpg" + hash).dontAnimate().into(holder.imageView);
        int id = list.get(position).getId();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MainActivity2.class);

                intent.putExtra("id", String.valueOf(id));
                context.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }








    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name,description;
        ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
           name=itemView.findViewById(R.id.name_tv);
           description=itemView.findViewById(R.id.desc_tv);
           imageView=itemView.findViewById(R.id.image_profile);

        }
    }

}